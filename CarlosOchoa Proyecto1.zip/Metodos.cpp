#include "Metodos.h"
#include <iostream>
using namespace std;

void Metodos::añadirLista(Nodo *&lista, int n) {
  Nodo *nuevo_nodo = new Nodo();
  nuevo_nodo->date = n;
  Nodo *last = NULL;
  Nodo *aux1 = lista;
  Nodo *aux2;

  while ((aux1 != NULL) && (aux1->date < n)) {
    aux2 = aux1;
    aux1 = aux1->next;
  }
  if (lista == aux1) {
    lista = nuevo_nodo;
  } else {
    aux2->next = nuevo_nodo;
  }
  nuevo_nodo->next = aux1;

  cout << "\tElemento " << n << " insertado a la lista correctamente\n";
}

void Metodos::enseñarLista(Nodo *lista) {
  Nodo *actual = new Nodo();
  actual = lista;

  while (actual != NULL) {
    cout << actual->date << " -> ";
    actual = actual->next;
  }

  if (lista == NULL) {
    cout << "La lista aún no cuenta con dates ingresados\n";
  }
}

void Metodos::buscarLista(Nodo *lista, int n) {
  bool bandera = false;
  Nodo *actual = new Nodo();
  actual = lista;

  while ((actual != NULL) && (actual->date <= n)) {
    if (actual->date == n) {
      bandera = true;
    }
    actual = actual->next;
  }
  if (bandera == true) {
    cout << "El número " << n << " SI ha sido encontrado en la lista\n";
  } else {
    cout << "El número " << n << " NO ha sido encontrado en la lista\n";
  }
}

void Metodos::eliminarNodo(Nodo *&lista, int n) {
  if (lista != NULL) {
    Nodo *aux_borrar;
    Nodo *last = NULL;

    aux_borrar = lista;

    while ((aux_borrar != NULL) && (aux_borrar->date != n)) {
      last = aux_borrar;
      aux_borrar = aux_borrar->next;
    }

    if (aux_borrar == NULL) {
      cout << "El número no ha sido encontrado\n";
    } else if (last == NULL) {
      lista = lista->next;
      delete aux_borrar;
      cout << "El número " << n
           << " ha sido eliminado correctamente de la lista\n";
    } else {
      last->next = aux_borrar->next;
      delete aux_borrar;
      cout << "El número " << n
           << " ha sido eliminado correctamente de la lista\n";
    }
  }
}

void Metodos::mostrarRepetidos(Nodo *lista) {
  Nodo *actual = new Nodo();
  actual = lista;
  Nodo *next = new Nodo();
  next = actual->next;
  while (actual != NULL) {

    while (next != NULL) {
      if (actual->date == next->date) {
        cout << "El número " << next->date << " se encuentra duplicado\n";
      }
      next = next->next;
    }
    actual = actual->next;
    next = actual->next;
  }
}

void Metodos::eliminarRepetidos(Nodo *&lista) {
  Nodo *actual = new Nodo();
  actual = lista;
  Nodo *next = new Nodo();
  next = actual->next;

  while (actual != NULL) {
    while (next != NULL) {
      if (actual->date == next->date) {
        eliminarNodo(lista, next->date);
      }
      next = next->next;
    }
    actual = actual->next;
    next = actual->next;
  }
}

void Metodos::hallarMayorMenor(Nodo *lista) {
  int mayor = 0, menor = 99999;

  while (lista != NULL) {        // recorremos la lista
    if ((lista->date) > mayor) { // calculando el mayor elemento
      mayor = lista->date;
    }
    if ((lista->date) < menor) { // calculando el menor elemento
      menor = lista->date;
    }
    lista = lista->next; // avanzamos una posicion en lista
  }

  cout << "\nEl mayor elemento es: " << mayor << endl;
  cout << "El menor elemento es: " << menor << endl;
}

void Metodos::invertirLista(Nodo *lista) {
  if (lista != NULL) {
    invertirLista(lista->next);
    cout << lista->date << " -> ";
  }
}

void Metodos::listaDecreciente(Nodo *&lista) {
  Nodo *aux1;
  Nodo *aux2;
  int aux;
  aux1 = lista;
  while (aux1->next != NULL) {
    aux2 = aux1->next;
    while (aux2 != NULL) {
      if (aux1->date < aux2->date) {
        aux = aux1->date;
        aux1->date = aux2->date;
        aux2->date = aux;
      }
      aux2 = aux2->next;
    }
    aux1 = aux1->next;
  }
}