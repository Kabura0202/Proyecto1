class Nodo {
public:
  struct {
    int date;
    Nodo *next;
  };
};