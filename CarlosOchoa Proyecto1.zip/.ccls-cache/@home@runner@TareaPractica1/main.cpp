#include "Metodos.h"
#include <iostream>
#include <stdlib.h>
using namespace std;

int main() {

  int opcion, dato;
  Nodo *lista = NULL;
  Metodos *metodos = new Metodos();

  do {
    cout << "\t.:MENU:.\n";
    cout << "1. Desea instertar un numero a la lista?\n";
    cout << "2. Mostrar numeros en la lista\n";
    cout << "3. Buscar numeros en la lista\n";
    cout << "4. Eliminar un numero de la lista\n";
    cout << "5. Calcular el numero menor y el numero mayor de la lista\n";
    cout << "6. Mostrar numeros repetidos de la lista\n";
    cout << "7. Eliminar numeros repetidos de la lista\n";
    cout << "8. Ordenar la lista actual de forma decreciente\n";
    cout << "9. Invertir la lista\n";
    cout << "10. Salir\n";
    cout << "Opcion: ";
    cin >> opcion;

    switch (opcion) {
    case 1:
      cout << "\nQue numero desea añadir: ";
      cin >> dato;
      metodos->añadirLista(lista, dato);
      cout << "\n";
      break;
    case 2:
      metodos->mostrarLista(lista);
      cout << "\n";
      break;
    case 3:
      cout << "\nDigite un número para buscarlo: ";
      cin >> dato;
      metodos->buscarLista(lista, dato);
      cout << "\n";
      break;
    case 4:
      cout << "\nDigite un número para eliminarlo: ";
      cin >> dato;
      metodos->eliminarNodo(lista, dato);
      cout << "\n";
      break;
    case 5:
      metodos->calcularMayorMenor(lista);
      cout << "\n";
      break;
    case 6:
      metodos->mostrarRepetidos(lista);
      cout << "\n";
      break;
    case 7:
      metodos->eliminarRepetidos(lista);
      cout << "\n";
      break;
    case 8:
      metodos->listaDecreciente(lista);
      cout << "Lista ordenada decrecientemente correctamente\n";
      cout << "\n";
      break;
    case 9:
      metodos->invertirLista(lista);
      cout << "\n";
      break;
    }
  } while (opcion != 10);
  return 0;
}