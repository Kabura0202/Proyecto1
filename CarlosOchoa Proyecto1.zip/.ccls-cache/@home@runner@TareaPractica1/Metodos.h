#ifndef METODOS_H
#define METODOS_H
#include "Nodo.h"

class Metodos {

public:
  void añadirLista(Nodo *&, int);
  void mostrarLista(Nodo *);
  void buscarLista(Nodo *, int);
  void eliminarNodo(Nodo *&, int);
  void calcularMayorMenor(Nodo *list);
  void mostrarRepetidos(Nodo *);
  void eliminarRepetidos(Nodo *&);
  void invertirLista(Nodo *list);
  void listaDecreciente(Nodo *&list);
};
#endif